/**
 * Script enable parallax-effect
 */
$(function () {
    'use strict';

    // Parallax effect for topic header
    $('.js-topic-parallax').parallax({
        position: 'center top'
    });
});