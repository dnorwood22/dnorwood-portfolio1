/**
 * Enable elastic for form component
 */
$(function () {
    'use strict';

    $('.elastic').elastic();
});