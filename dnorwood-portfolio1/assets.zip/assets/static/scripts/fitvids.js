/**
 * Fits video in resizable container
 */
$(function () {
    'use strict';

    // Target your .container, .wrapper, .post, etc.
    $(".fitvid").fitVids();
});